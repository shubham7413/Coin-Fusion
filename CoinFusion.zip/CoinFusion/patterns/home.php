<?php
/**
 * Title: Home
 * Slug: kortez-fse/home
 * Categories: home
 */
?>

<!-- wp:group {"tagName":"main","layout":{"type":"constrained"}} -->
<main class="wp-block-group">
<!-- wp:pattern {"slug":"kortez-fse/hero-banner"} /-->
<!-- wp:pattern {"slug":"kortez-fse/services"} /-->
<!-- wp:pattern {"slug":"kortez-fse/about"} /-->
<!-- wp:pattern {"slug":"kortez-fse/counter"} /-->
<!-- wp:pattern {"slug":"kortez-fse/testimonial"} /-->
<!-- wp:pattern {"slug":"kortez-fse/latest-posts"} /-->
<!-- wp:pattern {"slug":"kortez-fse/callback"} /-->
</main>
<!-- /wp:group -->